package com.capgemini.book_store.controller;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.book_store.bean.Book;
import com.capgemini.book_store.bean.Customer;
import com.capgemini.book_store.bean.Order;
import com.capgemini.book_store.bean.Review;
import com.capgemini.book_store.service.CustomerService;
import com.capgemini.book_store.service.OrderService;
import com.capgemini.book_store.service.ReviewService;

@RestController

public class CustomerController {

	@Autowired
	ReviewService reviewService;

	@Autowired
	CustomerService service;
	@Autowired
	OrderService orderService;
	List<Book> blist = new LinkedList<Book>();
	Order o;

	@RequestMapping(value = "/register", method = RequestMethod.PUT)
	public String Create(@RequestBody Customer customer) {
		/*
		 * //to check on the conditions of inputs!!!!
		 * 
		 */
		String emailId = customer.getEmailId();
		String customerName = customer.getCustomerName();
		String password = customer.getPassword();
		String confirmPassword = customer.getConfirmPassword();
		String mobileNumber = customer.getMobileNumber();
		String address = customer.getAddress();
		String city = customer.getCity();
		String zipcode = customer.getZipcode();
		String country = customer.getCountry();
		Customer c1 = service.Create(emailId, customerName, password, confirmPassword, mobileNumber, address, city,
				zipcode, country);
		if (c1 != null) {
			String register = "Customer Details:" + c1;
			return register;
		} else {
			return "Register it again...";
		}

	}

	@RequestMapping(value = "/validate/{emailId}/{password}", method = RequestMethod.POST)
	public String validate(@PathVariable("emailId") String emailId, @PathVariable("password") String password) {
		Customer c1 = service.validate(emailId, password);
		if (c1 != null) {
			return "successfull Login...." + c1.getCustomerName();
		}

		return "Invalid Credentials......";

	}

	@RequestMapping(value = "/editProfile", method = RequestMethod.PUT)
	public String update(@RequestBody Customer customer) {
		Customer c1 = service.update(customer);
		if (c1 != null)
			return "Succesfully Updated...";
		else
			return "Failed....";

	}

	@RequestMapping(value = "/viewOrder/{customerName}", method = RequestMethod.GET)
	public List<Order> viewOrder(@PathVariable("customerName") String customerName) {
		List<Order> order = orderService.vieworders(customerName);
		return order;
	}

	@RequestMapping(value = "/search/{bookName}", method = RequestMethod.GET)
	public String search(@PathVariable("bookName") String bookName) {
		System.out.println(bookName);
		Book b = reviewService.search(bookName);
		if (b != null) {
			String s = "Customer details are " + b;
			return s;
		} else
			return "Book not found!!!";
	}

	@RequestMapping(value ="/createReview", method = RequestMethod.PUT)
	public String create(@RequestBody Review review) {
		/*
		 * Customer customer=reviewService.validate(cname); if(customer!=null) { Review
		 * review=reviewService.CreateReview(cname, bookName, rating, headline,
		 * comment); reviewService.average(bookName, rating); return
		 * "Thank you for giving the review"; } else { return
		 * "Review can be given only once"; }
		 */

		
		Review rev = reviewService.CreateReview(review);
		reviewService.average(review.getBook().getTitle(),review.getRatings());
		return "Thank you for giving the review";
	}

	@RequestMapping(value = "/favbook", method = RequestMethod.GET)
	public List<Book> favBook() {
		List<Book> blist = reviewService.findByRating();
		return blist;
	}

	@RequestMapping(value = "/bestbook", method = RequestMethod.GET)
	public List<Book> bestBook() {
		List<Book> blist = reviewService.findByOrder();
		return blist;

	}

	@RequestMapping("/update/{quantity}/{bookname}")
	public String update(@PathVariable("quantity") int quantity, @PathVariable("bookname") String bookname) {
		Order o = orderService.update(quantity, bookname);
		return "updated quantity is " + o.getQuantity();

	}

	@RequestMapping(value = "/createOrder", method = RequestMethod.PUT)
	public String placeorder(@RequestBody Order order) {
		String bookname = order.getBookName();
		int quantity = order.getQuantity();
		String recipient = order.getReceipientName();
		Book b = orderService.findByBookName(bookname);
		double amount = b.getPrice();
		int bookId = b.getBookId();
		o = orderService.createOrder(quantity, amount, "COD", bookId, recipient, bookname);
		return "Your order has been placed successfuly" + o;

	}

	@RequestMapping("/display")
	public String DisplayAmount() {
		double o1 = orderService.invoice(o);
		return "The total amount for your order is " + o1;

	}

	@RequestMapping("/AddToCart/{bookname}")
	public List<Book> AddToCart(@PathVariable("bookname") String bookname) {
		Book b = orderService.findByBookName(bookname);
		blist.add(b);
		return blist;

	}

	@RequestMapping("/delete/{bookname}")
	public String delete(@PathVariable("bookname") String bookname) {
		Book b = orderService.findByBookName(bookname);
		// int id=b.getBookId();
		blist.remove(b);
		return "Successfully deleted";
	}

}
