package com.capgemini.book_store.bean;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Orders")
public class Order {
	@Id
	@GeneratedValue(generator = "order", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "order", sequenceName = "five", initialValue = 100, allocationSize = 1)
	private int orderId;

	@OneToOne
	private Customer customer;

	private int quantity;

	private double price;

	private String paymentMethod;

	private String orderDate;

	private String receipientName;

	private String orderStatus;
	private String bookName;

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	@OneToMany(targetEntity = BookDetail.class)
	private List<BookDetail> details;
	
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getReceipientName() {
		return receipientName;
	}

	public void setReceipientName(String receipientName) {
		this.receipientName = receipientName;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public List<BookDetail> getDetails() {
		return details;
	}

	public void setDetails(List<BookDetail> details) {
		this.details = details;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", customer=" + customer + ", quantity=" + quantity + ", price=" + price
				+ ", paymentMethod=" + paymentMethod + ", orderDate=" + orderDate + ", receipientName=" + receipientName
				+ ", orderStatus=" + orderStatus + ", bookName=" + bookName + ", details=" + details + "]";
	}

	

	

}
