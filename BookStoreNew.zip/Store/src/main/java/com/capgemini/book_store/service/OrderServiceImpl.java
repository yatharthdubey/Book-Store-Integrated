package com.capgemini.book_store.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.book_store.bean.Book;
import com.capgemini.book_store.bean.Customer;
import com.capgemini.book_store.bean.Order;
import com.capgemini.book_store.dao.IBookDAO;
import com.capgemini.book_store.dao.IOrderDAO;
@Service("orderService")
public class OrderServiceImpl implements OrderService {
@Autowired
IOrderDAO iOrderDAO;
@Autowired
IBookDAO iBookDAO;
private Book b;
	@Override
	public Book findByBookName(String bookname) {
		// TODO Auto-generated method stub
		Book b=iBookDAO.findBytitle(bookname);
		System.out.println(b);
		return b;
	}
   
	@Override
	public Order update(int quantity,String bookname) {
		b = null;
		int q2=b.getQuantity()+quantity;
		Order o=new Order();
		o.setQuantity(q2);
		iOrderDAO.save(o);
		return o;
	}

	@Override
	public Order createOrder(int quantity, double amount, String paymentmethod, int bookId,
			String recipient,String bookname) {
		double bAmount=(quantity*amount);
		Order o=new Order();
		o.setPrice(bAmount);
		o.setPaymentMethod(paymentmethod);
		o.setQuantity(quantity);
		o.setReceipientName(recipient);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println(dateFormat.format(date));
		String orderDate=dateFormat.format(date);
		o.setOrderDate(orderDate);
        o.setBookName(bookname);
		iOrderDAO.save(o);
		Book b=iBookDAO.findBytitle(bookname);
		int q2=b.getQuantity()+quantity;
		b.setQuantity(q2);
		iBookDAO.save(b);
		// TODO Auto-generated method stub
		return o;
	}

	@Override
	public List<Order> vieworders(String name) {
		List<Order> order=iOrderDAO.findByReceipientName(name);
		return order;
	}

	@Override
	public double invoice(Order o) {
		// TODO Auto-generated method stub
		double a=o.getPrice();
		return a;
	}

	
	
}
