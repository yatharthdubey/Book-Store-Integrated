package com.capgemini.book_store.service;

import java.util.List;

import com.capgemini.book_store.bean.Book;
import com.capgemini.book_store.bean.Customer;
import com.capgemini.book_store.bean.Order;

public interface OrderService 
{
public Book findByBookName (String bookname);
public Order update(int quantity,String bookname);
public Order createOrder(int quantity,double amount,String paymentmethod,int bookId,String recipient, String bookname);
public List<Order> vieworders(String name);
public double invoice(Order o);
}
