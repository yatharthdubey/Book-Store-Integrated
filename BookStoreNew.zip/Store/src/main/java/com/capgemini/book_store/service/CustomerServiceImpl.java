package com.capgemini.book_store.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.capgemini.book_store.bean.Customer;
import com.capgemini.book_store.dao.ICustomerDAO;

@Service("customerService")

public class CustomerServiceImpl implements CustomerService {
	@Autowired
	ICustomerDAO repo;

	@Override
	public Customer Create(String email, String cname, String password, String c_Password, String mobile,
			String address, String city, String zipcode, String country) {
		Customer c = new Customer();
		c.setEmailId(email);
		c.setCustomerName(cname);
		c.setPassword(password);
		c.setConfirmPassword(c_Password);
		c.setMobileNumber(mobile);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println(dateFormat.format(date));
		String registeredDate = dateFormat.format(date);
		c.setRegisterDate(registeredDate);
		c.setAddress(address);
		c.setCity(city);
		c.setZipcode(zipcode);
		c.setCountry(country);
		Customer c1 = repo.save(c);
		System.out.println(c1);
		return c1;

	}

	@Override
	public Customer validate(String email, String password) {
		System.out.println(email);
		Customer c = repo.findByEmailId(email);
		System.out.println(c);
		if (c != null) {
			if (c.getEmailId().equals(email) && c.getPassword().equals(password)) {
				return c;
			} else
				return null;
		}
		return null;
	}

	@Override
	public Customer update(Customer customer) {
		Customer c = repo.findByEmailId(customer.getEmailId());
		c.setCustomerName(customer.getCustomerName());
		c.setPassword(customer.getPassword());
		c.setConfirmPassword(customer.getConfirmPassword());
		c.setMobileNumber(customer.getMobileNumber());
		c.setAddress(customer.getAddress());
		c.setCity(customer.getCity());
		c.setZipcode(customer.getZipcode());
		c.setCountry(customer.getCountry());
		repo.save(c);
		return c;
	}

}
