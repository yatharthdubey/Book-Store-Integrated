package com.capgemini.book_store.service;

import com.capgemini.book_store.bean.Customer;

public interface CustomerService 
{
public Customer Create(String email,String cname,String password,String c_Password,String mobile,String address,String city,String zipcode,String country);
public Customer validate(String email,String password);
public Customer update(Customer customer);




























}
